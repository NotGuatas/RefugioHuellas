import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { adoptionsApi, dogsApi} from "../api";

export default function Adopt({ token }) {
  const { dogId } = useParams();
  const nav = useNavigate();

  const [dog, setDog] = useState(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setErr("");
    dogsApi
      .get(dogId, token)
      .then(setDog)
      .catch((e) => setErr(e.message));
  }, [dogId, token]);

  // Si no hay token, manda a login (manteniendo retorno)
  useEffect(() => {
    if (!token) nav(`/login?return=/adopt/${dogId}`);
  }, [token, nav, dogId]);

  async function submit(e) {
    e.preventDefault();
    setErr("");
    setOk("");
    setLoading(true);

    try {
      // Intenta crear adopción
      const res = await adoptionsApi.create(token, {
        dogId: Number(dogId),
        firstName,
        lastName,
        phone,
      });

      setOk(`${res.message} Compatibilidad: ${res.compatibilityScore}%`);
      // opcional: ir a "mis solicitudes"
      setTimeout(() => nav("/my-applications"), 600);
    } catch (e) {
      const msg = e.message || "Error";
      setErr(msg);

      // Si backend dice "perfil requerido", manda a profile
      if (msg.toLowerCase().includes("perfil")) {
        nav("/profile");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "grid", gap: 12, maxWidth: 520 }}>
      <Link to={`/dogs/${dogId}`}>← Volver</Link>

      <h2 style={{ margin: 0 }}>
        Solicitud de adopción {dog ? `– ${dog.name}` : ""}
      </h2>

      {err && <div style={{ color: "crimson" }}>{err}</div>}
      {ok && <div style={{ color: "green" }}>{ok}</div>}

      <form onSubmit={submit} style={{ display: "grid", gap: 10 }}>
        <label>
          Nombre
          <input
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="form-control"
            placeholder="Ej: Joseph"
          />
        </label>

        <label>
          Apellido
          <input
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="form-control"
            placeholder="Ej: Flores"
          />
        </label>

        <label>
          Teléfono (09xxxxxxxx)
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="form-control"
            placeholder="0991234567"
          />
        </label>

        <button className="btn btn-success" disabled={loading}>
          {loading ? "Enviando..." : "Enviar solicitud"}
        </button>
      </form>
    </div>
  );
}
