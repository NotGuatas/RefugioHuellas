import { apiFetch } from "./client";

// Exporta también las funciones sueltas (login, getDogs  por compatibilidad
export * from "./api";

export const authApi = {
  login: (email, password) =>
    apiFetch("/api/auth/login", { method: "POST", body: { email, password } }),

  me: (token) => apiFetch("/api/auth/me", { token }),
};

export const dogsApi = {
  list: () => apiFetch("/api/dogs"),
  get: (id, token) => apiFetch(`/api/dogs/${id}`, { token }),
};

export const traitsApi = {
  list: () => apiFetch("/api/traits"),
  my: (token) => apiFetch("/api/user-traits/me", { token }),
  saveMy: (token, items) =>
    apiFetch("/api/user-traits/me", { method: "POST", token, body: { items } }),
};

export const adoptionsApi = {
  create: (token, payload) =>
    apiFetch("/api/adoptions", { method: "POST", token, body: payload }),

  my: (token) => apiFetch("/api/adoptions/me", { token }),
};

